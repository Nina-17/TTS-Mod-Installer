# TTS 本地图包安装器 v0.2.0

Windows 上通过拖放，将 Tabletop Simulator 本地图包自动合并覆盖到游戏当前使用的 Mods 目录。

## 使用方法

下载发布包后请先选择“全部解压”，不要直接在 ZIP 预览窗口中运行启动器。

### 方法一：在窗口中拖入

1. 双击 `Install-TTS-Mods.cmd`。
2. 把一个或多个图包文件夹/压缩包拖进命令行窗口。
3. 按 Enter。

也可以输入 `F` 打开文件选择窗口。完成后可以继续安装下一批图包。

### 方法二：直接拖到启动器

把一个或多个图包文件夹/压缩包直接拖到 `Install-TTS-Mods.cmd` 图标上。

批量安装时只探测一次目标位置；如果 Game Data 目录需要管理员权限，只请求一次 UAC。

## 支持范围

- Windows 10/11。
- Windows PowerShell 5.1，无需安装 Python 或 Node.js。
- 文件夹和 ZIP 原生支持。
- 7Z/RAR：需要电脑中已经安装 7-Zip。
- 自动识别 Documents 和 Game Data 两种 TTS Mods 保存位置。
- 支持 Steam 默认库和其他磁盘上的附加 Steam 库。
- 解压前检查路径安全、文件数量、声明大小、异常压缩比和临时磁盘空间。

常见图包结构均可识别：

```text
Mods\Images
Mods\Models
Mods\Workshop
```

```text
图包名称\Mods\Images
```

```text
Images
Models
Workshop
```

## 覆盖规则

安装器执行“合并覆盖”：

- 图包中的新文件会添加。
- 同名文件会由图包版本覆盖；即使时间戳和大小相同，也以图包版本为准。
- 目标中其他已有 Mod 文件会保留。
- 不使用镜像同步，不删除目标中的文件。

如果 TTS 正在运行，安装器默认要求先退出游戏；它不会自动结束游戏进程。

## 自动路径识别

Documents 模式使用 Windows 当前用户真实的“文档”Known Folder，兼容 OneDrive 重定向：

```text
<文档>\My Games\Tabletop Simulator\Mods
```

Game Data 模式：

```text
<TTS安装目录>\Tabletop Simulator_Data\Mods
```

安装器会读取所有可解析的 `ConfigGame_h*` 配置：

- 多个配置结果一致：自动使用该位置。
- 配置结果互相冲突：列出配置和两个完整路径，让用户选择。
- 配置无法读取：根据目录存在情况判断；仍有歧义时让用户选择。

安装器不会在存在冲突时采用注册表枚举到的第一个结果。

## 命令行

也可以直接运行 PowerShell 主体：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\TTSModInstaller.ps1 "D:\Downloads\图包.zip"
```

可选参数：

```text
-LocationMode Auto|Documents|GameData
-DestinationPath <明确的目标 Mods 路径>
-ForceWhileRunning
-NonInteractive
```

`-DestinationPath` 主要用于测试或高级用法。使用它时，安装器不会再判断游戏当前的 Mods 设置。

## 日志

日志保存在：

```text
%LOCALAPPDATA%\TTSModInstaller\Logs
```

其中 `install-*.log` 是安装器流程日志，`robocopy-*.log` 是详细复制日志。

安装器会尽力清理：

- 30 天前的安装日志。
- 1 天前因异常退出遗留的解压目录和 UAC 交接文件。

当前安装正在使用的文件不会被清理。

如果复制已经开始后发生错误，部分文件可能已经写入目标。安装器会明确提示；修复磁盘空间、权限等问题后，可以重新安装同一个图包完成覆盖。

## 退出码

| 退出码 | 含义 |
|---:|---|
| 0 | 安装成功 |
| 1 | 用户取消或 TTS 仍在运行 |
| 2 | 输入无效或图包结构无法识别 |
| 3 | 无法定位 TTS/Mods 目标 |
| 4 | 解压失败 |
| 5 | 权限或 UAC 失败 |
| 8 | 文件复制失败 |
| 10 | 不是 Windows |
| 99 | 未分类异常 |

更完整的设计和验收矩阵见 [DESIGN.md](DESIGN.md)。

## 开发测试

在 Windows PowerShell 5.1 中运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Run-Tests.ps1
```

测试覆盖 TTS 配置解析与冲突处理、Steam 库解析、`robocopy` 退出码、多路径拖放、压缩包预检、ZIP 安全检查、Mods 包装目录识别和模拟批量端到端安装。

## 版本

- `v0.2.0`：增加配置冲突处理、压缩包预检、多图包批次、文件选择窗口、扫描进度、UAC 结果回传和旧文件清理。
- `v0.1.0`：最初的稳定脚本版，发布包继续保留在 `dist` 目录。
