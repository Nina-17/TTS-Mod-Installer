# TTS 本地图包安装器 v0.5.4

Windows 上通过拖放，将 Tabletop Simulator 本地图包自动合并覆盖到游戏当前使用的 Mods 目录。

## 使用方法

下载发布包后请先选择“全部解压”，不要直接在 ZIP 预览窗口中运行启动器。

### 方法一：在窗口中拖入

1. 双击 `点我启动.cmd`。
2. 把一个或多个图包文件夹/压缩包拖进命令行窗口。
3. 按 Enter。

也可以输入 `F` 打开文件选择窗口。完成后可以继续安装下一批图包。

### 方法二：直接拖到启动器

把一个或多个图包文件夹/压缩包直接拖到 `点我启动.cmd` 图标上。

批量安装时只探测一次目标位置；如果 Game Data 目录需要管理员权限，只请求一次 UAC。

## 支持范围

- Windows 10/11。
- Windows PowerShell 5.1，无需安装 Python 或 Node.js。
- 文件夹、ZIP 和 TTSMOD（`.ttsmod`）原生支持；`.ttsmod` 按 ZIP 处理。
- 7Z/RAR：发布包内置官方便携 7-Zip 26.02 组件，用户无需安装 7-Zip。
- 自动识别 Documents 和 Game Data 两种 TTS Mods 保存位置。
- 支持 Steam 默认库和其他磁盘上的附加 Steam 库。
- 解压前检查路径安全、文件数量、声明大小、异常压缩比和临时磁盘空间。
- 每次普通启动检查 GitHub 正式版更新，支持下载、校验、备份、替换和重新启动。

安装器会根据 Windows 原生架构自动选择内置的 x86、x64 或 ARM64 组件，并在运行前校验 `7z.exe` 和 `7z.dll` 的 SHA-256。若完整发布包中的内置组件不存在，仍会尝试使用电脑中已安装的 7-Zip 作为后备。

控制台界面以浅粉色为主，搭配低饱和丁香紫、雾蓝、薄荷绿、沙金和珊瑚红，并用状态 Emoji 和少量颜文字区分扫描、解压、复制、成功、警告与失败。Win11 终端优先显示柔和 RGB 配色，不支持真彩色的控制台会自动回退到兼容的 16 色；纯文本日志仍保留时间、级别和完整消息，方便排查问题。

常见图包结构均可识别：

```text
Mods\Images
Mods\Models
Mods\Workshop
```

```text
图包名称\Mods\Images
```

```text
Images
Models
Workshop
```

## 覆盖规则

安装器执行“合并覆盖”：

- 图包中的新文件会添加。
- 同名文件会由图包版本覆盖；即使时间戳和大小相同，也以图包版本为准。
- 目标中其他已有 Mod 文件会保留。
- 不使用镜像同步，不删除目标中的文件。

如果 TTS 正在运行，安装器默认要求先退出游戏；它不会自动结束游戏进程。

## 自动路径识别

Documents 模式使用 Windows 当前用户真实的“文档”Known Folder，兼容 OneDrive 重定向：

```text
<文档>\My Games\Tabletop Simulator\Mods
```

Game Data 模式：

```text
<TTS安装目录>\Tabletop Simulator_Data\Mods
```

安装器会读取所有可解析的 `ConfigGame_h*` 配置：

- 多个配置结果一致：自动使用该位置。
- 配置结果互相冲突：列出配置和两个完整路径，让用户选择。
- 配置无法读取：根据目录存在情况判断；仍有歧义时让用户选择。

安装器不会在存在冲突时采用注册表枚举到的第一个结果。

## 自动更新

安装器每次普通启动都会访问公开的 GitHub `releases/latest` 接口。GitHub 直连失败时会自动切换到 `gh-proxy.com`，Release 信息、更新 ZIP 和 SHA-256 文件都支持该备用通道。发现更高版本后：

- 输入 `U`：下载对应的完整发布 ZIP，一键更新。
- 输入 `S`：本次跳过，继续使用当前版本。
- GitHub 和备用通道都失败：显示警告并继续运行当前版本。

更新包必须同时满足以下条件才会安装：

- Release 中存在名称匹配的 `TTSModInstaller-vX.Y.Z.zip`。
- GitHub 资产 SHA-256 digest 或同名 `.sha256` 文件可用。
- 下载结果哈希一致。
- 解压后包含主脚本、CMD 启动器和更新助手。
- 包内版本号与 Release 标签一致。

更新助手会等待主安装器退出，备份当前核心文件，再合并覆盖新版；失败时尝试恢复旧版。更新不会删除安装器目录中的其他用户文件。内部提权子进程和 `-NonInteractive` 模式不会重复检查更新。

## 命令行

也可以直接运行 PowerShell 主体：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\TTSModInstaller.ps1 "D:\Downloads\图包.zip"
```

可选参数：

```text
-LocationMode Auto|Documents|GameData
-DestinationPath <明确的目标 Mods 路径>
-ForceWhileRunning
-NonInteractive
-SkipUpdateCheck
```

`-DestinationPath` 主要用于测试或高级用法。使用它时，安装器不会再判断游戏当前的 Mods 设置。

## 日志

安装器产生的运行数据全部保存在解压文件夹旁边：

```text
运行数据\
├─ Logs\       安装和 robocopy 日志
├─ Temp\       解压、UAC 交接和更新临时文件
└─ Backups\    自动更新前的版本备份
```

安装器不再使用 `%LOCALAPPDATA%` 或 Windows `%TEMP%` 保存自身数据。把整个解压文件夹放在 D 盘，以上数据也都会留在 D 盘。请勿只移动启动器，更新时也不要删除正在使用的 `运行数据` 文件夹。

`Logs\install-*.log` 是安装器流程日志，`Logs\robocopy-*.log` 是详细复制日志。

复制图包时，控制台显示单行循环进度条和轮换颜文字，不再逐文件刷屏；完整文件列表、摘要和退出码仍保存在 `robocopy-*.log` 中。进度条用于表明程序仍在工作，不显示虚假的整批百分比。

扫描完成后会同时显示“本次写入约”和“预计净增长”。同名文件覆盖仍要写入数据，但若新旧文件大小相同，预计净增长为 `0 B` 是正常现象。

安装器会尽力清理：

- 30 天前的安装日志。
- 30 天前的更新备份。
- 1 天前因异常退出遗留的解压、UAC 交接和更新临时文件。

当前安装正在使用的文件不会被清理。

7-Zip 返回非致命警告时，安装器会继续检查并安装能够正常读取的 Mods 内容，最终以黄色显示“安装完成，但压缩包处理有警告”。程序退出码仍为 `0`；如果游戏中出现素材缺失，建议重新获取或手动解压该图包。

如果复制已经开始后发生错误，部分文件可能已经写入目标。安装器会明确提示；修复磁盘空间、权限等问题后，可以重新安装同一个图包完成覆盖。

## 退出码

| 退出码 | 含义 |
|---:|---|
| 0 | 安装成功 |
| 1 | 用户取消或 TTS 仍在运行 |
| 2 | 输入无效或图包结构无法识别 |
| 3 | 无法定位 TTS/Mods 目标 |
| 4 | 解压失败 |
| 5 | 权限或 UAC 失败 |
| 8 | 文件复制失败 |
| 10 | 不是 Windows |
| 42 | 更新助手已启动，CMD 启动器直接退出 |
| 99 | 未分类异常 |

更完整的设计和验收矩阵见 [DESIGN.md](DESIGN.md)。

## 开发测试

在 Windows PowerShell 5.1 中运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Run-Tests.ps1
```

测试覆盖更新版本与资产解析、TTS 配置解析与冲突处理、Steam 库解析、`robocopy` 退出码、多路径拖放、压缩包预检、ZIP/TTSMOD 安全检查与解压、7Z/RAR 技术列表解析与警告语义、Mods 包装目录识别和模拟批量端到端安装。

## 版本

- `v0.5.4`：区分本次写入量与目标磁盘净增长；覆盖同名且同大小文件时，不再把 `0 B` 误解为没有复制；控制台配色重构为浅粉主色和低饱和辅助色。
- `v0.5.3`：用单行循环进度条和可爱颜文字替代 `robocopy` 的逐文件刷屏，保留完整 Unicode 复制日志。
- `v0.5.2`：启动器改名为 `点我启动.cmd`；日志、临时解压、UAC 交接、更新下载和备份全部改为保存在安装器文件夹内的 `运行数据`。
- `v0.5.1`：更新检查和发布资产下载支持 `gh-proxy.com`；GitHub 直连失败时自动切换并沿用备用通道。
- `v0.5.0`：新增每次启动检查 GitHub Release，以及完整包下载、SHA-256 校验、备份、自动替换、失败恢复和重新启动。
- `v0.4.2`：修复 Windows PowerShell 5.1 在转换泛型列表时可能出现的 `Argument types do not match` 错误。
- `v0.4.1`：修复 `.ttsmod` 在 Windows PowerShell 5.1 中受 `.zip` 扩展名限制而无法解压的问题，并修正发布包 SHA-256 清单中的文件路径。
- `v0.4.0`：新增 `.ttsmod` 支持，按普通 ZIP 图包完成预检、解压和 Mods 合并安装；不额外处理 `Saves`。
- `v0.3.0`：内置官方便携 7-Zip 26.02，7Z/RAR 不再要求用户预装软件；支持 x86、x64 和 ARM64，并校验组件哈希。
- `v0.2.0`：增加配置冲突处理、压缩包预检、多图包批次、文件选择窗口、扫描进度、UAC 结果回传和旧文件清理。
- `v0.1.0`：最初的稳定脚本版，发布包继续保留在 `dist` 目录。

## 第三方组件

发布包包含未经修改的 7-Zip 26.02 命令行组件。7-Zip 使用 GNU LGPL 等许可，详细声明见 `THIRD-PARTY-NOTICES.txt` 和发布包内的 `tools\7zip\License.txt`。源代码可从 [7-Zip 官网](https://www.7-zip.org/download.html) 获取。
