﻿[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$PackagePath,

    [string]$DestinationPath,

    [ValidateSet('Auto', 'Documents', 'GameData')]
    [string]$LocationMode = 'Auto',

    [switch]$Elevated,
    [switch]$ForceWhileRunning,
    [switch]$NonInteractive,
    [string]$HandoffPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:InstallerVersion = '0.1.0'
$script:LogPath = $null
$script:RoboCopyLogPath = $null
$script:IsWindowsPlatform = ($env:OS -eq 'Windows_NT')
$script:InstallerScriptPath = $PSCommandPath

function Throw-InstallerError {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $true)]
        [int]$ExitCode
    )

    $exception = New-Object System.InvalidOperationException -ArgumentList $Message
    $exception.Data['ExitCode'] = $ExitCode
    throw $exception
}

function Get-InstallerDataRoot {
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        return (Join-Path $env:LOCALAPPDATA 'TTSModInstaller')
    }

    return (Join-Path ([IO.Path]::GetTempPath()) 'TTSModInstaller')
}

function Initialize-InstallerLog {
    $logDirectory = Join-Path (Get-InstallerDataRoot) 'Logs'
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $script:LogPath = Join-Path $logDirectory ("install-{0}.log" -f $stamp)
    $script:RoboCopyLogPath = Join-Path $logDirectory ("robocopy-{0}.log" -f $stamp)

    $header = @(
        'TTS Mod Installer'
        ("Version: {0}" -f $script:InstallerVersion)
        ("Started: {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
        ("PowerShell: {0}" -f $PSVersionTable.PSVersion)
        ("OS: {0}" -f [Environment]::OSVersion.VersionString)
        ''
    )
    $header | Set-Content -LiteralPath $script:LogPath -Encoding UTF8
    return $script:LogPath
}

function Write-InstallerStatus {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [ValidateSet('INFO', 'OK', 'WARN', 'ERROR')]
        [string]$Level = 'INFO'
    )

    $color = 'Gray'
    switch ($Level) {
        'OK' { $color = 'Green' }
        'WARN' { $color = 'Yellow' }
        'ERROR' { $color = 'Red' }
    }

    $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'HH:mm:ss'), $Level, $Message
    Write-Host $line -ForegroundColor $color

    if (-not [string]::IsNullOrWhiteSpace($script:LogPath)) {
        $line | Add-Content -LiteralPath $script:LogPath -Encoding UTF8
    }
}

function ConvertTo-DisplaySize {
    param([Int64]$Bytes)

    if ($Bytes -ge 1TB) {
        return ('{0:N2} TB' -f ($Bytes / 1TB))
    }
    if ($Bytes -ge 1GB) {
        return ('{0:N2} GB' -f ($Bytes / 1GB))
    }
    if ($Bytes -ge 1MB) {
        return ('{0:N2} MB' -f ($Bytes / 1MB))
    }
    if ($Bytes -ge 1KB) {
        return ('{0:N2} KB' -f ($Bytes / 1KB))
    }
    return ('{0} B' -f $Bytes)
}

function Resolve-InstallerInputPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$InputPath
    )

    $candidate = $InputPath.Trim()
    if ($candidate.StartsWith('& ')) {
        $candidate = $candidate.Substring(2).Trim()
    }

    if ($candidate.Length -ge 2) {
        $first = $candidate.Substring(0, 1)
        $last = $candidate.Substring($candidate.Length - 1, 1)
        if (($first -eq '"' -and $last -eq '"') -or ($first -eq "'" -and $last -eq "'")) {
            $candidate = $candidate.Substring(1, $candidate.Length - 2)
        }
    }

    $candidate = [Environment]::ExpandEnvironmentVariables($candidate)
    if ($candidate -match '^[a-zA-Z]+://') {
        Throw-InstallerError -Message '请输入本地文件夹或压缩包路径，不能使用网络 URL。' -ExitCode 2
    }

    if (-not (Test-Path -LiteralPath $candidate)) {
        Throw-InstallerError -Message ("路径不存在：{0}" -f $candidate) -ExitCode 2
    }

    return (Get-Item -LiteralPath $candidate -Force).FullName
}

function Get-DocumentsModsPath {
    $documents = [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)
    if ([string]::IsNullOrWhiteSpace($documents)) {
        Throw-InstallerError -Message 'Windows 未返回当前用户的“文档”目录。' -ExitCode 3
    }

    return (Join-Path (Join-Path (Join-Path $documents 'My Games') 'Tabletop Simulator') 'Mods')
}

function Test-TTSInstallRoot {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $false
    }

    return (
        (Test-Path -LiteralPath (Join-Path $Path 'Tabletop Simulator.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $Path 'Tabletop Simulator_Data') -PathType Container)
    )
}

function Get-TTSRunningProcesses {
    if (-not $script:IsWindowsPlatform) {
        return @()
    }

    return @(Get-Process -Name 'Tabletop Simulator' -ErrorAction SilentlyContinue)
}

function Get-SteamLibrariesFromVdf {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Content
    )

    $results = New-Object System.Collections.Generic.List[string]
    $patterns = @(
        '(?im)^\s*"path"\s+"([^"]+)"',
        '(?im)^\s*"\d+"\s+"((?:[A-Za-z]:\\\\|\\\\\\\\)[^"]+)"'
    )

    foreach ($pattern in $patterns) {
        foreach ($match in [regex]::Matches($Content, $pattern)) {
            $path = $match.Groups[1].Value -replace '\\\\', '\'
            if (-not [string]::IsNullOrWhiteSpace($path)) {
                $results.Add($path)
            }
        }
    }

    return @($results)
}

function Get-SteamRootCandidates {
    $candidates = New-Object System.Collections.Generic.List[string]

    $registryEntries = @(
        @{ Path = 'HKCU:\Software\Valve\Steam'; Name = 'SteamPath' },
        @{ Path = 'HKCU:\Software\Valve\Steam'; Name = 'SteamExe' },
        @{ Path = 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam'; Name = 'InstallPath' },
        @{ Path = 'HKLM:\SOFTWARE\Valve\Steam'; Name = 'InstallPath' }
    )

    foreach ($entry in $registryEntries) {
        try {
            $value = (Get-ItemProperty -LiteralPath $entry.Path -Name $entry.Name -ErrorAction Stop).($entry.Name)
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                if ([IO.Path]::GetExtension($value) -ieq '.exe') {
                    $value = Split-Path -Parent $value
                }
                $candidates.Add($value)
            }
        }
        catch {
            # Registry variants are optional.
        }
    }

    if (-not [string]::IsNullOrWhiteSpace(${env:ProgramFiles(x86)})) {
        $candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Steam'))
    }
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $candidates.Add((Join-Path $env:ProgramFiles 'Steam'))
    }

    return @($candidates)
}

function Get-TTSInstallPath {
    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($process in (Get-TTSRunningProcesses)) {
        try {
            if (-not [string]::IsNullOrWhiteSpace($process.Path)) {
                $candidates.Add((Split-Path -Parent $process.Path))
            }
        }
        catch {
            # Process path can be unavailable without elevation.
        }
    }

    $uninstallKeys = @(
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 286160',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 286160',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 286160'
    )
    foreach ($key in $uninstallKeys) {
        try {
            $location = (Get-ItemProperty -LiteralPath $key -Name 'InstallLocation' -ErrorAction Stop).InstallLocation
            if (-not [string]::IsNullOrWhiteSpace($location)) {
                $candidates.Add($location)
            }
        }
        catch {
            # Not every Steam installation creates every uninstall key.
        }
    }

    foreach ($steamRoot in (Get-SteamRootCandidates)) {
        if ([string]::IsNullOrWhiteSpace($steamRoot)) {
            continue
        }

        $libraries = New-Object System.Collections.Generic.List[string]
        $libraries.Add($steamRoot)
        $vdfPath = Join-Path (Join-Path $steamRoot 'steamapps') 'libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdfPath -PathType Leaf) {
            try {
                $vdfContent = Get-Content -LiteralPath $vdfPath -Raw
                foreach ($library in (Get-SteamLibrariesFromVdf -Content $vdfContent)) {
                    $libraries.Add($library)
                }
            }
            catch {
                # Continue with the main Steam root.
            }
        }

        foreach ($library in $libraries) {
            $steamApps = Join-Path $library 'steamapps'
            $manifest = Join-Path $steamApps 'appmanifest_286160.acf'
            if (Test-Path -LiteralPath $manifest -PathType Leaf) {
                try {
                    $manifestContent = Get-Content -LiteralPath $manifest -Raw
                    $manifestMatch = [regex]::Match($manifestContent, '(?im)^\s*"installdir"\s+"([^"]+)"')
                    if ($manifestMatch.Success) {
                        $candidates.Add((Join-Path (Join-Path $steamApps 'common') $manifestMatch.Groups[1].Value))
                    }
                }
                catch {
                    # Fall back to the standard install directory name.
                }
            }

            $candidates.Add((Join-Path (Join-Path $steamApps 'common') 'Tabletop Simulator'))
        }
    }

    $seen = @{}
    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }

        $key = $candidate.TrimEnd('\', '/').ToLowerInvariant()
        if ($seen.ContainsKey($key)) {
            continue
        }
        $seen[$key] = $true

        if (Test-TTSInstallRoot -Path $candidate) {
            return (Get-Item -LiteralPath $candidate).FullName
        }
    }

    return $null
}

function Get-ConfigModeFromRawValue {
    param($RawValue)

    if ($null -eq $RawValue) {
        return $null
    }

    $textCandidates = New-Object System.Collections.Generic.List[string]
    if ($RawValue -is [byte[]]) {
        foreach ($encoding in @([Text.Encoding]::UTF8, [Text.Encoding]::Unicode, [Text.Encoding]::ASCII)) {
            try {
                $textCandidates.Add($encoding.GetString($RawValue))
            }
            catch {
                # Try the other encodings.
            }
        }
    }
    else {
        $textCandidates.Add([string]$RawValue)
    }

    $initialCandidates = @($textCandidates)
    foreach ($candidate in $initialCandidates) {
        $compact = ($candidate -replace "`0", '').Trim()
        if ($compact -match '^[A-Za-z0-9+/]+={0,2}$' -and $compact.Length -ge 8 -and ($compact.Length % 4) -eq 0) {
            try {
                $decodedBytes = [Convert]::FromBase64String($compact)
                $textCandidates.Add([Text.Encoding]::UTF8.GetString($decodedBytes))
                $textCandidates.Add([Text.Encoding]::Unicode.GetString($decodedBytes))
            }
            catch {
                # It only looked like base64.
            }
        }
    }

    foreach ($candidate in $textCandidates) {
        $clean = ($candidate -replace "`0", '').Trim()
        $start = $clean.IndexOf('{')
        $end = $clean.LastIndexOf('}')
        if ($start -lt 0 -or $end -le $start) {
            continue
        }

        try {
            $jsonText = $clean.Substring($start, $end - $start + 1)
            $config = $jsonText | ConvertFrom-Json
            if ($null -ne $config.ConfigMods -and $null -ne $config.ConfigMods.Location) {
                $location = [int]$config.ConfigMods.Location
                if ($location -eq 0) {
                    return 'Documents'
                }
                if ($location -eq 1) {
                    return 'GameData'
                }
            }
        }
        catch {
            # Continue trying other encodings/candidates.
        }
    }

    return $null
}

function Get-TTSModLocationSetting {
    if (-not $script:IsWindowsPlatform) {
        return $null
    }

    $registryPath = 'HKCU:\Software\Berserk Games\Tabletop Simulator'
    try {
        $key = Get-Item -LiteralPath $registryPath -ErrorAction Stop
        foreach ($valueName in $key.GetValueNames()) {
            if ($valueName -notlike 'ConfigGame_h*') {
                continue
            }

            $rawValue = $key.GetValue($valueName, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $mode = Get-ConfigModeFromRawValue -RawValue $rawValue
            if ($null -ne $mode) {
                return [pscustomobject]@{
                    Mode = $mode
                    Reason = ("TTS 配置 {0}" -f $valueName)
                }
            }
        }
    }
    catch {
        return $null
    }

    return $null
}

function Resolve-TTSModsDestination {
    param(
        [string]$ExplicitDestination,
        [ValidateSet('Auto', 'Documents', 'GameData')]
        [string]$RequestedMode = 'Auto',
        [switch]$NoPrompt
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitDestination)) {
        $expanded = [Environment]::ExpandEnvironmentVariables($ExplicitDestination)
        if (Test-Path -LiteralPath $expanded -PathType Leaf) {
            Throw-InstallerError -Message ("目标路径是文件而不是目录：{0}" -f $expanded) -ExitCode 3
        }
        return [pscustomobject]@{
            Path = [IO.Path]::GetFullPath($expanded)
            Mode = 'Explicit'
            Reason = '提权前或命令行已明确指定'
            InstallRoot = $null
            DocumentsPath = $null
            GameDataPath = $null
        }
    }

    $documentsPath = Get-DocumentsModsPath
    $installRoot = Get-TTSInstallPath
    $gameDataPath = $null
    if (-not [string]::IsNullOrWhiteSpace($installRoot)) {
        $gameDataPath = Join-Path (Join-Path $installRoot 'Tabletop Simulator_Data') 'Mods'
    }

    if ($RequestedMode -eq 'Documents') {
        return [pscustomobject]@{
            Path = $documentsPath
            Mode = 'Documents'
            Reason = '命令行指定'
            InstallRoot = $installRoot
            DocumentsPath = $documentsPath
            GameDataPath = $gameDataPath
        }
    }

    if ($RequestedMode -eq 'GameData') {
        if ([string]::IsNullOrWhiteSpace($gameDataPath)) {
            Throw-InstallerError -Message '已指定 Game Data 模式，但未找到有效的 TTS 安装目录。' -ExitCode 3
        }
        return [pscustomobject]@{
            Path = $gameDataPath
            Mode = 'GameData'
            Reason = '命令行指定'
            InstallRoot = $installRoot
            DocumentsPath = $documentsPath
            GameDataPath = $gameDataPath
        }
    }

    $setting = Get-TTSModLocationSetting
    if ($null -ne $setting) {
        if ($setting.Mode -eq 'Documents') {
            return [pscustomobject]@{
                Path = $documentsPath
                Mode = 'Documents'
                Reason = $setting.Reason
                InstallRoot = $installRoot
                DocumentsPath = $documentsPath
                GameDataPath = $gameDataPath
            }
        }

        if ([string]::IsNullOrWhiteSpace($gameDataPath)) {
            Throw-InstallerError -Message 'TTS 配置为 Game Data，但脚本未找到有效的 TTS 安装目录。' -ExitCode 3
        }
        return [pscustomobject]@{
            Path = $gameDataPath
            Mode = 'GameData'
            Reason = $setting.Reason
            InstallRoot = $installRoot
            DocumentsPath = $documentsPath
            GameDataPath = $gameDataPath
        }
    }

    $documentsExists = Test-Path -LiteralPath $documentsPath -PathType Container
    $gameDataExists = (
        -not [string]::IsNullOrWhiteSpace($gameDataPath) -and
        (Test-Path -LiteralPath $gameDataPath -PathType Container)
    )

    if ($documentsExists -and -not $gameDataExists) {
        return [pscustomobject]@{
            Path = $documentsPath
            Mode = 'Documents'
            Reason = '配置无法读取，仅 Documents Mods 目录存在'
            InstallRoot = $installRoot
            DocumentsPath = $documentsPath
            GameDataPath = $gameDataPath
        }
    }

    if ($gameDataExists -and -not $documentsExists) {
        return [pscustomobject]@{
            Path = $gameDataPath
            Mode = 'GameData'
            Reason = '配置无法读取，仅 Game Data Mods 目录存在'
            InstallRoot = $installRoot
            DocumentsPath = $documentsPath
            GameDataPath = $gameDataPath
        }
    }

    if ($NoPrompt) {
        Throw-InstallerError -Message '无法自动判断 TTS 当前使用的 Mods 位置；非交互模式下不能询问用户。' -ExitCode 3
    }

    Write-Host ''
    Write-Host '无法从 TTS 配置唯一确定 Mods 位置，请选择本次安装目标：' -ForegroundColor Yellow
    Write-Host ("  [1] Documents：{0}" -f $documentsPath)
    if (-not [string]::IsNullOrWhiteSpace($gameDataPath)) {
        Write-Host ("  [2] Game Data：{0}" -f $gameDataPath)
    }
    else {
        Write-Host '  [2] Game Data：未找到 TTS 安装目录，当前不可选' -ForegroundColor DarkGray
    }

    while ($true) {
        $choice = (Read-Host '请选择 1 或 2（默认 1）').Trim()
        if ([string]::IsNullOrWhiteSpace($choice) -or $choice -eq '1') {
            return [pscustomobject]@{
                Path = $documentsPath
                Mode = 'Documents'
                Reason = '用户选择'
                InstallRoot = $installRoot
                DocumentsPath = $documentsPath
                GameDataPath = $gameDataPath
            }
        }
        if ($choice -eq '2' -and -not [string]::IsNullOrWhiteSpace($gameDataPath)) {
            return [pscustomobject]@{
                Path = $gameDataPath
                Mode = 'GameData'
                Reason = '用户选择'
                InstallRoot = $installRoot
                DocumentsPath = $documentsPath
                GameDataPath = $gameDataPath
            }
        }
        Write-Host '输入无效，请输入 1 或 2。' -ForegroundColor Yellow
    }
}

function Wait-ForSafeGameState {
    param(
        [switch]$AllowRunning,
        [switch]$NoPrompt
    )

    if (@(Get-TTSRunningProcesses).Count -eq 0) {
        return $false
    }

    if ($AllowRunning) {
        Write-InstallerStatus -Level WARN -Message '检测到 TTS 正在运行；已按参数要求继续。'
        return $true
    }

    if ($NoPrompt) {
        Throw-InstallerError -Message 'TTS 正在运行。请先退出游戏，或显式使用 -ForceWhileRunning。' -ExitCode 1
    }

    Write-InstallerStatus -Level WARN -Message '检测到 TTS 正在运行。游戏可能同时写入 Mods 缓存。'
    while (@(Get-TTSRunningProcesses).Count -gt 0) {
        $choice = (Read-Host '退出游戏后按 Enter 重新检测；输入 C 强制继续；输入 Q 取消').Trim()
        if ($choice -ieq 'Q') {
            Throw-InstallerError -Message '用户取消安装。' -ExitCode 1
        }
        if ($choice -ieq 'C') {
            Write-InstallerStatus -Level WARN -Message '用户选择在 TTS 运行时继续。'
            return $true
        }
    }

    Write-InstallerStatus -Level OK -Message '已确认 TTS 退出。'
    return $false
}

function Test-DestinationWriteAccess {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $probePath = $null
    try {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
        $probePath = Join-Path $Path ('.tts-mod-installer-write-test-{0}.tmp' -f [guid]::NewGuid().ToString('N'))
        $stream = [IO.File]::Open(
            $probePath,
            [IO.FileMode]::CreateNew,
            [IO.FileAccess]::Write,
            [IO.FileShare]::None
        )
        $stream.Dispose()
        Remove-Item -LiteralPath $probePath -Force
        return $true
    }
    catch {
        if ($null -ne $probePath -and (Test-Path -LiteralPath $probePath)) {
            try {
                Remove-Item -LiteralPath $probePath -Force
            }
            catch {
                # Best effort cleanup.
            }
        }
        return $false
    }
}

function Invoke-ElevatedInstaller {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourcePath,

        [Parameter(Mandatory = $true)]
        [string]$TargetPath,

        [switch]$ContinueWhileRunning,
        [switch]$NoPrompt
    )

    $handoffDirectory = Join-Path ([IO.Path]::GetTempPath()) 'TTSModInstaller-Handoff'
    New-Item -ItemType Directory -Path $handoffDirectory -Force | Out-Null
    $handoffFile = Join-Path $handoffDirectory (([guid]::NewGuid().ToString('N')) + '.json')

    $handoff = [ordered]@{
        PackagePath = $SourcePath
        DestinationPath = $TargetPath
        ForceWhileRunning = [bool]$ContinueWhileRunning
        NonInteractive = [bool]$NoPrompt
    }
    $handoff | ConvertTo-Json | Set-Content -LiteralPath $handoffFile -Encoding UTF8

    $scriptPath = $script:InstallerScriptPath
    if ([string]::IsNullOrWhiteSpace($scriptPath)) {
        $scriptPath = Join-Path $PSScriptRoot 'TTSModInstaller.ps1'
    }

    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}" -HandoffPath "{1}" -Elevated' -f $scriptPath, $handoffFile
    Write-InstallerStatus -Level WARN -Message '目标目录需要管理员权限，即将请求 Windows UAC。'

    try {
        $process = Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        return [int]$process.ExitCode
    }
    catch {
        Throw-InstallerError -Message ("管理员权限请求失败或被取消：{0}" -f $_.Exception.Message) -ExitCode 5
    }
    finally {
        if (Test-Path -LiteralPath $handoffFile) {
            try {
                Remove-Item -LiteralPath $handoffFile -Force
            }
            catch {
                # Elevated child normally removes it.
            }
        }
    }
}

function Find-7ZipExecutable {
    foreach ($commandName in @('7z.exe', '7z')) {
        $command = Get-Command $commandName -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -ne $command) {
            return $command.Source
        }
    }

    $candidates = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $candidates.Add((Join-Path (Join-Path $env:ProgramFiles '7-Zip') '7z.exe'))
    }
    if (-not [string]::IsNullOrWhiteSpace(${env:ProgramFiles(x86)})) {
        $candidates.Add((Join-Path (Join-Path ${env:ProgramFiles(x86)} '7-Zip') '7z.exe'))
    }

    foreach ($registryPath in @('HKLM:\SOFTWARE\7-Zip', 'HKLM:\SOFTWARE\WOW6432Node\7-Zip')) {
        try {
            $sevenZipRoot = (Get-ItemProperty -LiteralPath $registryPath -Name 'Path' -ErrorAction Stop).Path
            if (-not [string]::IsNullOrWhiteSpace($sevenZipRoot)) {
                $candidates.Add((Join-Path $sevenZipRoot '7z.exe'))
            }
        }
        catch {
            # Registry entry is optional.
        }
    }

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return $candidate
        }
    }

    return $null
}

function Assert-ZipEntriesSafe {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ArchivePath
    )

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::OpenRead($ArchivePath)
    try {
        foreach ($entry in $archive.Entries) {
            $entryPath = $entry.FullName.Replace('\', '/')
            $segments = @($entryPath.Split('/') | Where-Object { $_ -ne '' })
            if (
                $entryPath.StartsWith('/') -or
                $entryPath -match '^[A-Za-z]:' -or
                ($segments -contains '..')
            ) {
                Throw-InstallerError -Message ("ZIP 中包含不安全路径：{0}" -f $entry.FullName) -ExitCode 4
            }
        }
    }
    finally {
        $archive.Dispose()
    }
}

function Expand-ModPackage {
    param(
        [Parameter(Mandatory = $true)]
        [string]$InputPath
    )

    $item = Get-Item -LiteralPath $InputPath -Force
    if ($item.PSIsContainer) {
        return [pscustomobject]@{
            Root = $item.FullName
            TemporaryRoot = $null
            Tool = 'Folder'
        }
    }

    $extension = $item.Extension.ToLowerInvariant()
    if ($extension -notin @('.zip', '.7z', '.rar')) {
        Throw-InstallerError -Message ("不支持的文件类型：{0}。支持文件夹、ZIP，以及安装 7-Zip 后的 7Z/RAR。" -f $extension) -ExitCode 2
    }

    $tempBase = Join-Path ([IO.Path]::GetTempPath()) 'TTSModInstaller'
    New-Item -ItemType Directory -Path $tempBase -Force | Out-Null
    $tempRoot = Join-Path $tempBase ([guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot | Out-Null

    try {
        if ($extension -eq '.zip') {
            Assert-ZipEntriesSafe -ArchivePath $item.FullName
            Write-InstallerStatus -Message '正在解压 ZIP 图包……'
            Expand-Archive -LiteralPath $item.FullName -DestinationPath $tempRoot -Force
            $tool = 'Expand-Archive'
        }
        else {
            $sevenZip = Find-7ZipExecutable
            if ([string]::IsNullOrWhiteSpace($sevenZip)) {
                Throw-InstallerError -Message '该压缩包需要 7-Zip。请安装 7-Zip，或将图包转换为 ZIP。' -ExitCode 4
            }

            Write-InstallerStatus -Message ("正在使用 7-Zip 解压 {0}……" -f $extension.ToUpperInvariant())
            & $sevenZip 'x' $item.FullName ("-o{0}" -f $tempRoot) '-y' '-bso0' '-bsp0' 2>&1 |
                ForEach-Object { Write-Host $_ }
            $sevenZipExitCode = $LASTEXITCODE
            if ($sevenZipExitCode -gt 1) {
                Throw-InstallerError -Message ("7-Zip 解压失败，退出码：{0}" -f $sevenZipExitCode) -ExitCode 4
            }
            $tool = $sevenZip
        }

        return [pscustomobject]@{
            Root = $tempRoot
            TemporaryRoot = $tempRoot
            Tool = $tool
        }
    }
    catch {
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
        throw
    }
}

function Test-IsReparsePoint {
    param(
        [Parameter(Mandatory = $true)]
        [IO.FileSystemInfo]$Item
    )

    return (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
}

function Resolve-SourceModsRoot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RootPath
    )

    $rootItem = Get-Item -LiteralPath $RootPath -Force
    if (-not $rootItem.PSIsContainer) {
        Throw-InstallerError -Message '图包分析根路径不是文件夹。' -ExitCode 2
    }
    if (Test-IsReparsePoint -Item $rootItem) {
        Throw-InstallerError -Message '图包根目录是符号链接或目录联接，出于安全原因拒绝处理。' -ExitCode 2
    }

    if ($rootItem.Name -ieq 'Mods') {
        return $rootItem.FullName
    }

    $directDirectories = @(Get-ChildItem -LiteralPath $rootItem.FullName -Directory -Force)
    $directMods = @($directDirectories | Where-Object { $_.Name -ieq 'Mods' })
    if ($directMods.Count -eq 1) {
        return $directMods[0].FullName
    }

    $nestedMods = @()
    foreach ($directory in $directDirectories) {
        foreach ($child in @(Get-ChildItem -LiteralPath $directory.FullName -Directory -Force -ErrorAction SilentlyContinue)) {
            if ($child.Name -ieq 'Mods') {
                $nestedMods += $child
            }
        }
    }

    if ($nestedMods.Count -eq 1) {
        return $nestedMods[0].FullName
    }
    if ($nestedMods.Count -gt 1) {
        $candidateText = (@($nestedMods | ForEach-Object { $_.FullName }) -join [Environment]::NewLine)
        Throw-InstallerError -Message ("图包中发现多个 Mods 候选，无法安全选择：{0}{1}" -f [Environment]::NewLine, $candidateText) -ExitCode 2
    }

    $knownDirectories = @(
        'Images',
        'Models',
        'Workshop',
        'Assetbundles',
        'Audio',
        'Textures',
        'PDF',
        'Images Raw',
        'Models Raw'
    )
    $markerCount = @($directDirectories | Where-Object { $knownDirectories -contains $_.Name }).Count
    if ($markerCount -gt 0) {
        return $rootItem.FullName
    }

    Throw-InstallerError -Message '没有找到可识别的 Mods 结构。请选择 Mods 文件夹，或包含 Mods 文件夹的图包。' -ExitCode 2
}

function Get-CopySummary {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceRoot,

        [Parameter(Mandatory = $true)]
        [string]$TargetRoot
    )

    $sourcePrefixLength = $SourceRoot.TrimEnd('\', '/').Length
    [Int64]$totalBytes = 0
    [Int64]$requiredGrowthBytes = 0
    [int]$fileCount = 0
    [int]$conflictCount = 0

    foreach ($entry in (Get-ChildItem -LiteralPath $SourceRoot -Recurse -Force)) {
        if (Test-IsReparsePoint -Item $entry) {
            Throw-InstallerError -Message ("图包包含符号链接或目录联接，出于安全原因拒绝处理：{0}" -f $entry.FullName) -ExitCode 2
        }
        if ($entry.PSIsContainer) {
            continue
        }

        $fileCount++
        $totalBytes += [Int64]$entry.Length
        $relativePath = $entry.FullName.Substring($sourcePrefixLength).TrimStart('\', '/')
        $targetFile = Join-Path $TargetRoot $relativePath
        if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
            $conflictCount++
            try {
                $existingLength = [Int64](Get-Item -LiteralPath $targetFile -Force).Length
                if ($entry.Length -gt $existingLength) {
                    $requiredGrowthBytes += ([Int64]$entry.Length - $existingLength)
                }
            }
            catch {
                $requiredGrowthBytes += [Int64]$entry.Length
            }
        }
        else {
            $requiredGrowthBytes += [Int64]$entry.Length
        }
    }

    if ($fileCount -eq 0) {
        Throw-InstallerError -Message '识别出的 Mods 目录中没有任何文件。' -ExitCode 2
    }

    [Nullable[Int64]]$freeBytes = $null
    try {
        $driveRoot = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($TargetRoot))
        if (-not [string]::IsNullOrWhiteSpace($driveRoot)) {
            $driveInfo = New-Object System.IO.DriveInfo -ArgumentList $driveRoot
            $freeBytes = [Int64]$driveInfo.AvailableFreeSpace
        }
    }
    catch {
        # UNC and unusual filesystems may not expose free space.
    }

    return [pscustomobject]@{
        FileCount = $fileCount
        TotalBytes = $totalBytes
        ConflictCount = $conflictCount
        RequiredGrowthBytes = $requiredGrowthBytes
        FreeBytes = $freeBytes
    }
}

function Assert-SafeCopyRelationship {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceRoot,

        [Parameter(Mandatory = $true)]
        [string]$TargetRoot
    )

    $source = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\', '/')
    $target = [IO.Path]::GetFullPath($TargetRoot).TrimEnd('\', '/')
    if ($source.Equals($target, [StringComparison]::OrdinalIgnoreCase)) {
        Throw-InstallerError -Message '图包来源和安装目标是同一个目录，已停止以避免无意义覆盖。' -ExitCode 2
    }

    $separator = [IO.Path]::DirectorySeparatorChar
    if (
        $source.StartsWith($target + $separator, [StringComparison]::OrdinalIgnoreCase) -or
        $target.StartsWith($source + $separator, [StringComparison]::OrdinalIgnoreCase)
    ) {
        Throw-InstallerError -Message '图包来源和安装目标互相嵌套，已停止以避免递归复制。' -ExitCode 2
    }
}

function Test-RobocopyExitCode {
    param([int]$ExitCode)
    return ($ExitCode -ge 0 -and $ExitCode -lt 8)
}

function Invoke-ModCopy {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceRoot,

        [Parameter(Mandatory = $true)]
        [string]$TargetRoot
    )

    $robocopy = Get-Command 'robocopy.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $robocopy) {
        Throw-InstallerError -Message '系统中未找到 robocopy.exe。' -ExitCode 8
    }

    $arguments = @(
        $SourceRoot,
        $TargetRoot,
        '/E',
        '/COPY:DAT',
        '/DCOPY:DAT',
        '/R:2',
        '/W:1',
        '/XJ',
        '/IS',
        '/IT',
        '/NP',
        '/TEE',
        ("/UNILOG:{0}" -f $script:RoboCopyLogPath)
    )

    Write-InstallerStatus -Message '开始合并覆盖；目标中其他已有文件会保留。'
    & $robocopy.Source @arguments 2>&1 | ForEach-Object { Write-Host $_ }
    $exitCode = $LASTEXITCODE

    ("Robocopy log: {0}" -f $script:RoboCopyLogPath) | Add-Content -LiteralPath $script:LogPath -Encoding UTF8
    ("Robocopy exit code: {0}" -f $exitCode) | Add-Content -LiteralPath $script:LogPath -Encoding UTF8

    if (-not (Test-RobocopyExitCode -ExitCode $exitCode)) {
        Throw-InstallerError -Message ("文件复制失败，robocopy 退出码为 {0}。详细信息：{1}" -f $exitCode, $script:RoboCopyLogPath) -ExitCode 8
    }

    return $exitCode
}

function Remove-OwnedTemporaryRoot {
    param([string]$TemporaryRoot)

    if ([string]::IsNullOrWhiteSpace($TemporaryRoot) -or -not (Test-Path -LiteralPath $TemporaryRoot)) {
        return
    }

    $expectedBase = (Join-Path ([IO.Path]::GetTempPath()) 'TTSModInstaller').TrimEnd('\', '/')
    $fullTemporaryRoot = [IO.Path]::GetFullPath($TemporaryRoot).TrimEnd('\', '/')
    $expectedPrefix = $expectedBase + [IO.Path]::DirectorySeparatorChar
    if (-not $fullTemporaryRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        Write-InstallerStatus -Level WARN -Message ("拒绝清理不属于安装器的临时路径：{0}" -f $fullTemporaryRoot)
        return
    }

    try {
        Remove-Item -LiteralPath $fullTemporaryRoot -Recurse -Force
        Write-InstallerStatus -Message '已清理解压临时目录。'
    }
    catch {
        Write-InstallerStatus -Level WARN -Message ("临时目录清理失败，可稍后手动删除：{0}" -f $fullTemporaryRoot)
    }
}

function Read-InstallerHandoff {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Throw-InstallerError -Message '提权交接文件不存在。' -ExitCode 5
    }

    try {
        $data = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        return $data
    }
    finally {
        Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-OnePackageInstall {
    param(
        [Parameter(Mandatory = $true)]
        [string]$InputPath,

        [string]$ExplicitDestination,

        [ValidateSet('Auto', 'Documents', 'GameData')]
        [string]$RequestedMode = 'Auto',

        [switch]$AlreadyElevated,
        [switch]$AllowRunning,
        [switch]$NoPrompt
    )

    $temporaryRoot = $null
    Initialize-InstallerLog | Out-Null

    try {
        Write-InstallerStatus -Message ("TTS 本地图包安装器 v{0}" -f $script:InstallerVersion)
        $resolvedInput = Resolve-InstallerInputPath -InputPath $InputPath
        Write-InstallerStatus -Message ("图包输入：{0}" -f $resolvedInput)

        $destination = Resolve-TTSModsDestination `
            -ExplicitDestination $ExplicitDestination `
            -RequestedMode $RequestedMode `
            -NoPrompt:$NoPrompt

        if (-not [string]::IsNullOrWhiteSpace($destination.InstallRoot)) {
            Write-InstallerStatus -Message ("TTS 安装目录：{0}" -f $destination.InstallRoot)
        }
        Write-InstallerStatus -Message ("Mods 模式：{0}（{1}）" -f $destination.Mode, $destination.Reason)
        Write-InstallerStatus -Message ("安装目标：{0}" -f $destination.Path)

        $continuedWhileRunning = Wait-ForSafeGameState -AllowRunning:$AllowRunning -NoPrompt:$NoPrompt
        if ($continuedWhileRunning) {
            $AllowRunning = $true
        }

        if (-not (Test-DestinationWriteAccess -Path $destination.Path)) {
            if ($AlreadyElevated) {
                Throw-InstallerError -Message ("即使以管理员身份运行也无法写入目标目录：{0}" -f $destination.Path) -ExitCode 5
            }

            $elevatedExitCode = Invoke-ElevatedInstaller `
                -SourcePath $resolvedInput `
                -TargetPath $destination.Path `
                -ContinueWhileRunning:$AllowRunning `
                -NoPrompt:$NoPrompt
            if ($elevatedExitCode -eq 0) {
                Write-InstallerStatus -Level OK -Message '管理员进程已完成安装。'
            }
            else {
                Write-InstallerStatus -Level ERROR -Message ("管理员进程安装失败，退出码：{0}" -f $elevatedExitCode)
            }
            return $elevatedExitCode
        }

        $expanded = Expand-ModPackage -InputPath $resolvedInput
        $temporaryRoot = $expanded.TemporaryRoot
        Write-InstallerStatus -Message ("输入处理方式：{0}" -f $expanded.Tool)

        $sourceRoot = Resolve-SourceModsRoot -RootPath $expanded.Root
        Write-InstallerStatus -Message ("识别出的 Mods 根：{0}" -f $sourceRoot)

        Assert-SafeCopyRelationship -SourceRoot $sourceRoot -TargetRoot $destination.Path
        $summary = Get-CopySummary -SourceRoot $sourceRoot -TargetRoot $destination.Path
        Write-InstallerStatus -Message ("文件：{0}，总大小：{1}，同名目标文件：{2}" -f `
            $summary.FileCount,
            (ConvertTo-DisplaySize -Bytes $summary.TotalBytes),
            $summary.ConflictCount)

        if ($null -ne $summary.FreeBytes) {
            Write-InstallerStatus -Message ("目标磁盘可用空间：{0}；预计净增长：{1}" -f `
                (ConvertTo-DisplaySize -Bytes $summary.FreeBytes),
                (ConvertTo-DisplaySize -Bytes $summary.RequiredGrowthBytes))

            $reserve = 64MB
            if ($summary.FreeBytes -lt ($summary.RequiredGrowthBytes + $reserve)) {
                Throw-InstallerError -Message '目标磁盘可用空间不足（已预留 64 MB 安全余量）。' -ExitCode 8
            }
        }
        else {
            Write-InstallerStatus -Level WARN -Message '无法读取目标磁盘可用空间，将继续复制。'
        }

        $robocopyExitCode = Invoke-ModCopy -SourceRoot $sourceRoot -TargetRoot $destination.Path
        Write-InstallerStatus -Level OK -Message ("安装完成（robocopy 退出码 {0}）。" -f $robocopyExitCode)
        Write-InstallerStatus -Level OK -Message ("目标：{0}" -f $destination.Path)
        Write-InstallerStatus -Message ("日志：{0}" -f $script:LogPath)
        return 0
    }
    catch {
        $exitCode = 99
        if ($null -ne $_.Exception.Data['ExitCode']) {
            $exitCode = [int]$_.Exception.Data['ExitCode']
        }
        Write-InstallerStatus -Level ERROR -Message $_.Exception.Message
        Write-InstallerStatus -Level ERROR -Message ("安装未完成。日志：{0}" -f $script:LogPath)
        return $exitCode
    }
    finally {
        Remove-OwnedTemporaryRoot -TemporaryRoot $temporaryRoot
    }
}

function Invoke-InstallerEntryPoint {
    if (-not $script:IsWindowsPlatform) {
        Write-Host '此安装器只能在 Windows 上实际运行。' -ForegroundColor Red
        return 10
    }

    $effectivePackagePath = $PackagePath
    $effectiveDestinationPath = $DestinationPath
    $effectiveForceWhileRunning = [bool]$ForceWhileRunning
    $effectiveNonInteractive = [bool]$NonInteractive

    if (-not [string]::IsNullOrWhiteSpace($HandoffPath)) {
        try {
            $handoff = Read-InstallerHandoff -Path $HandoffPath
            $effectivePackagePath = [string]$handoff.PackagePath
            $effectiveDestinationPath = [string]$handoff.DestinationPath
            $effectiveForceWhileRunning = [bool]$handoff.ForceWhileRunning
            $effectiveNonInteractive = [bool]$handoff.NonInteractive
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
            return 5
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($effectivePackagePath)) {
        return (Invoke-OnePackageInstall `
            -InputPath $effectivePackagePath `
            -ExplicitDestination $effectiveDestinationPath `
            -RequestedMode $LocationMode `
            -AlreadyElevated:$Elevated `
            -AllowRunning:$effectiveForceWhileRunning `
            -NoPrompt:$effectiveNonInteractive)
    }

    if ($effectiveNonInteractive) {
        Write-Host '非交互模式必须通过参数提供图包路径。' -ForegroundColor Red
        return 2
    }

    Write-Host ''
    Write-Host 'TTS 本地图包安装器' -ForegroundColor Cyan
    Write-Host '把图包文件夹或压缩包拖入此窗口，然后按 Enter。输入 Q 可退出。'

    while ($true) {
        Write-Host ''
        $inputValue = (Read-Host '图包路径').Trim()
        if ($inputValue -ieq 'Q') {
            return 0
        }
        if ([string]::IsNullOrWhiteSpace($inputValue)) {
            continue
        }

        $result = Invoke-OnePackageInstall `
            -InputPath $inputValue `
            -RequestedMode $LocationMode `
            -AlreadyElevated:$Elevated

        Write-Host ''
        if ($result -eq 0) {
            $next = (Read-Host '按 Enter 安装下一个图包，输入 Q 退出').Trim()
        }
        else {
            $next = (Read-Host '按 Enter 重新选择图包，输入 Q 退出').Trim()
        }
        if ($next -ieq 'Q') {
            return $result
        }
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $finalExitCode = Invoke-InstallerEntryPoint
    exit $finalExitCode
}
