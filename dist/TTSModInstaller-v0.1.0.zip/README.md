# TTS 本地图包安装器

Windows 上通过拖放，将 Tabletop Simulator 本地图包自动合并覆盖到游戏当前使用的 Mods 目录。

## 使用方法

### 方法一：在窗口中拖入

1. 双击 `Install-TTS-Mods.cmd`。
2. 把图包文件夹或压缩包拖进命令行窗口。
3. 按 Enter。

完成后可以继续拖入下一个图包。

### 方法二：直接拖到启动器

把图包文件夹或压缩包直接拖到 `Install-TTS-Mods.cmd` 图标上。

## 支持范围

- Windows 10/11。
- Windows PowerShell 5.1，无需安装 Python 或 Node.js。
- 文件夹和 ZIP 原生支持。
- 7Z/RAR：需要电脑中已经安装 7-Zip。
- 自动识别 Documents 和 Game Data 两种 TTS Mods 保存位置。
- 支持 Steam 默认库和其他磁盘上的附加 Steam 库。

常见图包结构均可识别：

```text
Mods\Images
Mods\Models
Mods\Workshop
```

```text
图包名称\Mods\Images
```

```text
Images
Models
Workshop
```

## 覆盖规则

安装器执行“合并覆盖”：

- 图包中的新文件会添加。
- 同名文件会由图包版本覆盖；即使时间戳和大小相同，也以图包版本为准。
- 目标中其他已有 Mod 文件会保留。
- 不使用镜像同步，不删除目标中的文件。

如果 TTS 正在运行，安装器默认要求先退出游戏；它不会自动结束游戏进程。

## 自动路径识别

Documents 模式使用 Windows 当前用户真实的“文档”Known Folder，兼容 OneDrive 重定向：

```text
<文档>\My Games\Tabletop Simulator\Mods
```

Game Data 模式：

```text
<TTS安装目录>\Tabletop Simulator_Data\Mods
```

安装器优先读取 TTS 当前用户配置中的 `ConfigMods.Location`。如果内部配置格式发生变化，则根据目录存在情况判断；仍有歧义时会显示完整路径让用户选择，不会静默猜测。

## 命令行

也可以直接运行 PowerShell 主体：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\TTSModInstaller.ps1 "D:\Downloads\图包.zip"
```

可选参数：

```text
-LocationMode Auto|Documents|GameData
-DestinationPath <明确的目标 Mods 路径>
-ForceWhileRunning
-NonInteractive
```

`-DestinationPath` 主要用于测试或高级用法。使用它时，安装器不会再判断游戏当前的 Mods 设置。

## 日志

日志保存在：

```text
%LOCALAPPDATA%\TTSModInstaller\Logs
```

其中 `install-*.log` 是安装器流程日志，`robocopy-*.log` 是详细复制日志。

## 退出码

| 退出码 | 含义 |
|---:|---|
| 0 | 安装成功 |
| 1 | 用户取消或 TTS 仍在运行 |
| 2 | 输入无效或图包结构无法识别 |
| 3 | 无法定位 TTS/Mods 目标 |
| 4 | 解压失败 |
| 5 | 权限或 UAC 失败 |
| 8 | 文件复制失败 |
| 10 | 不是 Windows |
| 99 | 未分类异常 |

更完整的设计和验收矩阵见 [DESIGN.md](DESIGN.md)。

## 开发测试

在 Windows PowerShell 5.1 中运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Run-Tests.ps1
```

测试覆盖 TTS 配置解析、Steam 库解析、`robocopy` 退出码、拖放路径规范化、ZIP 安全检查、Mods 包装目录识别和一次模拟端到端安装。
