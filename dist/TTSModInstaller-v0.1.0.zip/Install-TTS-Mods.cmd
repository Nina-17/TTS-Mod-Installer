@echo off
setlocal
chcp 65001 >nul
title TTS 本地图包安装器

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TTSModInstaller.ps1" %*
set "installer_exit_code=%ERRORLEVEL%"

echo.
if not "%installer_exit_code%"=="0" (
    echo 安装器退出码：%installer_exit_code%
)
pause
exit /b %installer_exit_code%
